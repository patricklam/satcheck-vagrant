NIDHUGG=~/nidhugg/
