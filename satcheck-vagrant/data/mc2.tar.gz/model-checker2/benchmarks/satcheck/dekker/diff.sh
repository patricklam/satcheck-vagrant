#!/bin/sh
NAME=dekker
diff -ub ../../satcheck-precompiled/${NAME}/dekker-fences.c dekker-fences.c
