#!/bin/sh
rm -f dekker-fences dekker-fences.c dimacs.out dimacs.cnf logall log_file
