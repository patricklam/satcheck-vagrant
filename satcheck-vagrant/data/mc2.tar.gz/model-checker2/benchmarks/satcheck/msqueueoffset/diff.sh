#!/bin/sh
NAME=msqueueoffset
diff -ub ../../satcheck-precompiled/$NAME/ms-queue-simple.c ms-queue-simple.c

