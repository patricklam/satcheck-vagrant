MC2DIR=/home/plam/hacking/model-checker2
