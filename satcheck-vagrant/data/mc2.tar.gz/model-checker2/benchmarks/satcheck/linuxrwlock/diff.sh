#!/bin/sh
NAME=linuxrwlock
diff -ub ../../satcheck-precompiled/$NAME/linuxrwlocks.c linuxrwlocks.c

