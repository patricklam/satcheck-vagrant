#!/bin/bash
rm -f linuxlocks.c linuxlocks dimacs.out dimacs.cnf logall log_file
