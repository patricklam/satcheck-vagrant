#!/bin/sh
NAME=seqlock
diff -ub ../../satcheck/$NAME/seqlock.cc.in seqlock.cc

