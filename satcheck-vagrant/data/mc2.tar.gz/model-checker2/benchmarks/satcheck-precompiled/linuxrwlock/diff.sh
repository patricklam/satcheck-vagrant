#!/bin/sh
NAME=linuxrwlock
diff -ub ../../satcheck/$NAME/linuxrwlocks.c.in linuxrwlocks.c

