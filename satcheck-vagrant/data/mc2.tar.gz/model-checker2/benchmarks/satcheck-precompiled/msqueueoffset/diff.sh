#!/bin/sh
NAME=msqueueoffset
diff -ub ../../satcheck/$NAME/ms-queue-simple.c.in ms-queue-simple.c

