#!/bin/sh
NAME=dekker
diff -ub ../../satcheck/${NAME}/dekker-fences.c.in dekker-fences.c
