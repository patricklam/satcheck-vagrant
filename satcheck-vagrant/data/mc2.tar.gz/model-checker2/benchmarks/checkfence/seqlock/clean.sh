#!/bin/bash
rm T0.*.htm
rm T0.bsc*
rm T0.prn
rm seqlock.c
rm seqlock.lsl
rm seqlock.i
rm runlog