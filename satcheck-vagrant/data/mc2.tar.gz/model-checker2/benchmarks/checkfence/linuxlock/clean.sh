#!/bin/bash
rm T0.*.htm
rm T0.bsc*
rm T0.prn
rm lin_harness.i
rm lin_harness.lsl
rm linuxrwlocksbig.c
rm runlog