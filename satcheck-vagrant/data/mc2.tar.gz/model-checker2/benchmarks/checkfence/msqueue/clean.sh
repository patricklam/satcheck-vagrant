#!/bin/bash
rm T0.*.htm
rm T0.bsc*
rm T0.prn
rm msn_harness.i
rm msn_harness.lsl
rm msn_harness.c
rm runlog