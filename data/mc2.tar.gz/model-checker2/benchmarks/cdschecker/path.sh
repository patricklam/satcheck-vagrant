CDSCHECKERDIR=~/research/model-checker/
