#!/bin/bash
rm -f linuxrwlocks.cc linuxrwlocks dimacs.out dimacs.cnf logall log_file
