#!/bin/bash
rm -f seqlock.cc seqlock dimacs.out dimacs.cnf logall log_file
