#!/bin/sh
NAME=linuxlock
diff -ub ../../satcheck/$NAME/linuxlocks.c.in linuxlocks.c

