export C2LSL_HOME=~/checkfence/c2lsl/
export PATH=~/checkfence/c2lsl/bin:$PATH
export CHECKFENCE_HOME=~/checkfence/checkfence
export PATH=~/checkfence/checkfence/run:$PATH
