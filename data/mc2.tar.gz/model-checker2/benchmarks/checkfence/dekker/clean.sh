#!/bin/bash
rm T0.*.htm
rm T0.bsc*
rm T0.prn
rm dekker-fences.c
rm dekker-fences.i
rm dekker-fences.lsl
rm runlog
