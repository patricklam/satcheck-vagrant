#!/bin/bash
rm T0.*.htm
rm T0.bsc*
rm T0.prn
rm add_harness.i
rm add_harness.lsl
rm llock.c
rm runlog