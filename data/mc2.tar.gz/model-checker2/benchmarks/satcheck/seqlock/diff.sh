#!/bin/sh
NAME=seqlock
diff -ub ../../satcheck-precompiled/$NAME/seqlock.cc seqlock.cc

