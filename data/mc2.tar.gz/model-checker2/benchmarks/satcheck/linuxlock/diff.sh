#!/bin/sh
NAME=linuxlock
diff -ub ../../satcheck-precompiled/$NAME/linuxlocks.c linuxlocks.c

